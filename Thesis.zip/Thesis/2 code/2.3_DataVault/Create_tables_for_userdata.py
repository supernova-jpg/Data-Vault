# Author: Xintong Chen
# Time: 2021-12-1 17:45:04

# Create table for the management of web users in the database 'userdata' and insert one row of data
# You can also insert data by registering in the web after running .py of Django

# Find config.ini
import os
import configparser
cf = configparser.ConfigParser()
cf.read(os.path.dirname(os.getcwd()) + '/' + 'config.ini')

# ↓ -----CONFIG----- ↓
project_file_name = cf.get('Path','project_file_name')
database_name = "userdata"
database_user = cf.get('Postgresql','database_user')
database_password = cf.get('Postgresql','database_password')
database_host = cf.get('Postgresql','database_host')
database_port = cf.get('Postgresql','database_port')
# ↑ -----CONFIG----- ↑

import psycopg2

class Progresql_Conn:
    def __init__(self):
        self.conn = psycopg2.connect(database=database_name, user=database_user,
                                password=database_password, host=database_host, port=database_port)
        self.cursor = self.conn.cursor()

    def execute_sql(self, sql):
        self.cursor.execute(sql)
        self.conn.commit()

    def close(self):
        self.conn.close()

posgre_insert = Progresql_Conn()
posgre_insert.execute_sql('''
Create table authuser (
    username varchar(50),
    password varchar(50),
    usertype varchar(25),
    primary key (username));
Insert INTO authuser Values ('lisheng','woshishuaibi','admin');
''')
posgre_insert.close()
print("Successfully create table for userdata!")