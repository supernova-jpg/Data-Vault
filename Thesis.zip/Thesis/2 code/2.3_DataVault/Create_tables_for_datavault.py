# Author: Xintong Chen
# Time: 2021-12-1 17:45:04

# Create tables for DataVault

# Find config.ini
import os
import configparser
cf = configparser.ConfigParser()
cf.read(os.path.dirname(os.getcwd()) + '/' + 'config.ini')

# ↓ -----CONFIG----- ↓
project_file_name = cf.get('Path','project_file_name')
database_name = "datavault_smd_sp_g01"
database_user = cf.get('Postgresql','database_user')
database_password = cf.get('Postgresql','database_password')
database_host = cf.get('Postgresql','database_host')
database_port = cf.get('Postgresql','database_port')
# ↑ -----CONFIG----- ↑

import psycopg2

class Progresql_Conn:
    def __init__(self):
        self.conn = psycopg2.connect(database=database_name, user=database_user,
                                password=database_password, host=database_host, port=database_port)
        self.cursor = self.conn.cursor()

    def execute_sql(self, sql):
        self.cursor.execute(sql)
        self.conn.commit()

    def close(self):
        self.conn.close()

posgre_insert = Progresql_Conn()
posgre_insert.execute_sql('''
-- HubExperment
CREATE Table HubExperiment(
	HashKeyExperiment VARCHAR(40),
	ExperimentID VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyExperiment)
);

-- SatExperiment
CREATE TABLE SatExperiment(
	HashKeySatExperiment VARCHAR(40),
	LoadDate TIMESTAMP,
	LoadEndDate TIMESTAMP,
	RecordSource VARCHAR(80),
	HashDiff VARCHAR(40),
	ResearchName VARCHAR(40),
	Researcher VARCHAR(40),
	Institute VARCHAR(40),
	PRIMARY KEY (HashKeySatExperiment, LoadDate),
	FOREIGN KEY (HashKeySatExperiment) REFERENCES HubExperiment(HashKeyExperiment)
);

-- Subject
CREATE Table HubSubject(
	HashKeySubject VARCHAR(40),
	SubjectID VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeySubject)
);

-- SatSubject
CREATE TABLE SatSubject(
	HashKeySatSubject VARCHAR(40),
	LoadDate TIMESTAMP,
	LoadEndDate TIMESTAMP,
	RecordSource VARCHAR(80),
	HashDiff VARCHAR(40),
	Name VARCHAR(40),
	Age VARCHAR(10),
	Sex VARCHAR(10),
	Comment VARCHAR(400),
	PRIMARY KEY (HashKeySatSubject, LoadDate),
	FOREIGN KEY (HashKeySatSubject) REFERENCES HubSubject(HashKeySubject)
);

-- Link Experment, Subject 
CREATE Table LinkSubjectExp(
	HashKeyToSubjectExp VARCHAR(40),
	HashKeyExperiment VARCHAR(40),
	HashKeySubject VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyToSubjectExp),
	FOREIGN KEY (HashKeyExperiment) REFERENCES HubExperiment(HashKeyExperiment),
	FOREIGN KEY (HashKeySubject) REFERENCES HubSubject(HashKeySubject)
);

-- Session
CREATE Table HubSession(
	HashKeySession VARCHAR(40),
	SessionID VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeySession)
);

-- SatSession 
CREATE TABLE SatSession(
	HashKeySatSession VARCHAR(40),
	LoadDate TIMESTAMP,
	LoadEndDate TIMESTAMP,
	RecordSource VARCHAR(80),
	HashDiff VARCHAR(40),
	Name VARCHAR(30),
	Description VARCHAR(200),
	PRIMARY KEY (HashKeySatSession, LoadDate),
	FOREIGN KEY (HashKeySatSession) REFERENCES HubSession(HashKeySession)
);

-- Link Experment, Session 
CREATE Table LinkSessionExp(
	HashKeySessionExp VARCHAR(40),
	HashKeyExperiment VARCHAR(40),
	HashKeySession VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeySessionExp),
	FOREIGN KEY (HashKeyExperiment) REFERENCES HubExperiment(HashKeyExperiment),
	FOREIGN KEY (HashKeySession) REFERENCES HubSession(HashKeySession)
);

-- Measurement
CREATE Table HubMeasurement(
	HashKeyMeasurement VARCHAR(40),
	MeasurementID VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyMeasurement)
);

-- SatSession 
CREATE TABLE SatMeasurement(
	HashKeySatMeasurement VARCHAR(40),
	LoadDate TIMESTAMP,
	LoadEndDate TIMESTAMP,
	RecordSource VARCHAR(80),
	HashDiff VARCHAR(40),
	Name VARCHAR(30),
	Description VARCHAR(200),
	PRIMARY KEY (HashKeySatMeasurement, LoadDate),
	FOREIGN KEY (HashKeySatMeasurement) REFERENCES HubMeasurement(HashKeyMeasurement)
);

-- Link Experment, Measurement
CREATE Table LinkMeasurementExp(
	HashKeyMeasurementExp VARCHAR(40),
	HashKeyExperiment VARCHAR(40),
	HashKeyMeasurement VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyMeasurementExp),
	FOREIGN KEY (HashKeyExperiment) REFERENCES HubExperiment(HashKeyExperiment),
	FOREIGN KEY (HashKeyMeasurement) REFERENCES HubMeasurement(HashKeyMeasurement)
);

-- MetaData
CREATE Table HubMetaData(
	HashKeyMetaData VARCHAR(40),
	MetaDtaID VARCHAR(80),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyMetaData)
);

-- SatMetaData
CREATE TABLE SatMetaData(
	HashKeySatMetaData VARCHAR(40),
	LoadDate TIMESTAMP,
	LoadEndDate TIMESTAMP,
	RecordSource VARCHAR(80),
	HashDiff VARCHAR(40),
	MetaKey VARCHAR(50),
	MetaValue VARCHAR(800),
	PRIMARY KEY (HashKeySatMetaData, LoadDate),
	FOREIGN KEY (HashKeySatMetaData) REFERENCES HubMetaData(HashKeyMetaData)
);

-- Link Experment, Measurement
/*
CREATE Table LinkMetaDataExp(
	HashKeyMetaDataExp VARCHAR(40),
	HashKeyExperiment VARCHAR(40),
	
	HashKeyMetaData VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyMetaDataExp),
	FOREIGN KEY (HashKeyExperiment) REFERENCES HubExperiment(HashKeyExperiment),
	FOREIGN KEY (HashKeyMetaData) REFERENCES HubMetaData(HashKeyMetaData)
);
*/

-- Factor
CREATE Table HubFactor(
	HashKeyFactor VARCHAR(40),
	FactorID VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyFactor)
);

-- SatFactor
CREATE TABLE SatFactor(
	HashKeySatFactor VARCHAR(40),
	LoadDate TIMESTAMP,
	LoadEndDate TIMESTAMP,
	RecordSource VARCHAR(80),
	HashDiff VARCHAR(40),
	FactorType VARCHAR(20),
	Unit VARCHAR(20),
	Value Numeric(40),
	PRIMARY KEY (HashKeySatFactor, LoadDate),
	FOREIGN KEY (HashKeySatFactor) REFERENCES HubFactor(HashKeyFactor)
);

-- ExperimentUnit
CREATE Table HubExperimentUnit(
	HashKeyExperimentUnit VARCHAR(40),
	ExperimentUnitID VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyExperimentUnit)
);

-- Link Subject, Session -> ExperimentUnit
CREATE Table LinkExperimentUnit(
	HashKeyLinkExperimentUnit VARCHAR(40),
	HashKeyExperimentUnit VARCHAR(40),
	HashKeySubject VARCHAR(40),
	HashKeySession VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyLinkExperimentUnit),
	FOREIGN KEY (HashKeyExperimentUnit) REFERENCES HubExperimentUnit(HashKeyExperimentUnit),
	FOREIGN KEY (HashKeySubject) REFERENCES HubSubject(HashKeySubject),
	FOREIGN KEY (HashKeySession) REFERENCES HubSession(HashKeySession)
);

-- Data
CREATE Table HubData(
	HashKeyData VARCHAR(40),
	DataID VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyData)
);

-- SatData
CREATE TABLE SatData(
	HashKeySatData VARCHAR(40),
	LoadDate TIMESTAMP,
	LoadEndDate TIMESTAMP,
	RecordSource VARCHAR(80),
	HashDiff VARCHAR(40),
	myFile bytea,
	code_method VARCHAR(40),
	PRIMARY KEY (HashKeySatData, LoadDate),
	FOREIGN KEY (HashKeySatData) REFERENCES HubData(HashKeyData)
);

-- Link Factor, Measurement, ExperimentUnit -> Data
CREATE Table LinkData(
	HashKeyLinkData VARCHAR(40),
	HashKeyFactor VARCHAR(40),
	HashKeyMeasurement VARCHAR(40),
	HashKeyExperimentUnit VARCHAR(40),
	HashKeyData VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyLinkData),
	FOREIGN KEY (HashKeyFactor) REFERENCES HubFactor(HashKeyFactor),
	FOREIGN KEY (HashKeyMeasurement) REFERENCES HubMeasurement(HashKeyMeasurement),
	FOREIGN KEY (HashKeyExperimentUnit) REFERENCES HubExperimentUnit(HashKeyExperimentUnit),
	FOREIGN KEY (HashKeyData) REFERENCES HubData(HashKeyData)
);

-- ProcessedData
CREATE Table HubProcessedData(
	HashKeyProcessedData VARCHAR(40),
	ProcessedDataID VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(120),
	PRIMARY KEY (HashKeyProcessedData)
);

-- SatData
CREATE TABLE SatProcessedData(
	HashKeySatProcessedData VARCHAR(40),
	LoadDate TIMESTAMP,
	LoadEndDate TIMESTAMP,
	RecordSource VARCHAR(80),
	HashDiff VARCHAR(40),
	myFile bytea,
	decode_method VARCHAR(40),
	PRIMARY KEY (HashKeySatProcessedData, LoadDate),
	FOREIGN KEY (HashKeySatProcessedData) REFERENCES HubProcessedData(HashKeyProcessedData)
);

-- Link Data -> ProcessedData
CREATE Table LinkDataPro(
	HashKeyDataPro VARCHAR(40),
	HashKeyData VARCHAR(40),
	HashKeyProcessedData VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyDataPro),
	FOREIGN KEY (HashKeyData) REFERENCES HubData(HashKeyData),
	FOREIGN KEY (HashKeyProcessedData) REFERENCES HubProcessedData(HashKeyProcessedData)
);

-- Subject -> Meta
CREATE Table LinkSubjectMeta(
	HashKeySubjectMeta VARCHAR(40),
	HashKeySubject VARCHAR(40),
	HashKeyMetaData VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeySubjectMeta),
	FOREIGN KEY (HashKeySubject) REFERENCES HubSubject(HashKeySubject),
	FOREIGN KEY (HashKeyMetaData) REFERENCES HubMetaData(HashKeyMetaData)
);

-- ExperimentUnit, Measurement -> Meta
CREATE Table LinkUnitMeta(
	HashKeyUnitMeta VARCHAR(40),
	HashKeyExperimentUnit VARCHAR(40),
	HashKeyMeasurement VARCHAR(40),
	HashKeyMetaData VARCHAR(40),
	LoadDate TIMESTAMP,
	RecordSource VARCHAR(80),
	PRIMARY KEY (HashKeyUnitMeta),
	FOREIGN KEY (HashKeyExperimentUnit) REFERENCES HubExperimentUnit(HashKeyExperimentUnit),
	FOREIGN KEY (HashKeyMeasurement) REFERENCES HubMeasurement(HashKeyMeasurement),
	FOREIGN KEY (HashKeyMetaData) REFERENCES HubMetaData(HashKeyMetaData)
);
''')
posgre_insert.close()
print("Successfully create tables for DataVault!")