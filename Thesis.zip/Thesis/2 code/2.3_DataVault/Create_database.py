# Author: Xintong Chen
# Time: 2021-12-1 17:45:04

# Create database 'datavault_smd_sp_g01' for data vault
# Create database 'userdata' for the management of web users

# Find config.ini
import os
import configparser
cf = configparser.ConfigParser()
cf.read(os.path.dirname(os.getcwd()) + '/' + 'config.ini')

# ↓ -----CONFIG----- ↓
project_file_name = cf.get('Path','project_file_name')
database_name = "postgres"
database_user = cf.get('Postgresql','database_user')
database_password = cf.get('Postgresql','database_password')
database_host = cf.get('Postgresql','database_host')
database_port = cf.get('Postgresql','database_port')
# ↑ -----CONFIG----- ↑

import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

DATABASE_NAME = 'datavault_smd_sp_g01'
DATABASE_NAME2 = 'userdata'

DB_NAME = """
CREATE DATABASE {};
""".format(DATABASE_NAME)

DB_NAME2 = """
CREATE DATABASE {};
""".format(DATABASE_NAME2)

conn = psycopg2.connect(database=database_name, user=database_user,
                                password=database_password, host=database_host, port=database_port)
conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
conn.autocommit = True
cur = conn.cursor()
cur.execute(DB_NAME)
conn.autocommit = True
cur.execute(DB_NAME2)
cur.close()
conn.close()
print("Successfully create 2 databases!")