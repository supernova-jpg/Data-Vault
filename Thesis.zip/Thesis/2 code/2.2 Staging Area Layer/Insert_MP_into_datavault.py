# Author: Xintong Chen
# Time: 2021-11-18 13:21:04

# Find config.ini
import os
import configparser
cf = configparser.ConfigParser()
cf.read(os.path.dirname(os.getcwd()) + '/' + 'config.ini')

# ↓ -----CONFIG----- ↓
fnirs_path = cf.get('Path','fnirs_path')
egg_path = cf.get('Path','egg_path')
project_file_name = cf.get('Path','project_file_name')
database_name = "datavault_smd_sp_g01"
database_user = cf.get('Postgresql','database_user')
database_password = cf.get('Postgresql','database_password')
database_host = cf.get('Postgresql','database_host')
database_port = cf.get('Postgresql','database_port')
# ↑ -----CONFIG----- ↑



import os
import psycopg2
import datetime
import hashlib
import pandas as pd
from tqdm import tqdm
import binascii
import h5py
import time

# The time we insert the data.
def now():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

# The data is valid!
def notnow():
    return '9999-12-31 24:00:00'

# hash by SHA-1
def hash(x):
    sha1 = hashlib.sha1(x.encode('utf-8'))
    return sha1.hexdigest()

# Connect to the PostgreSQL
class Progresql_Conn:
    def __init__(self):
        self.conn = psycopg2.connect(database=database_name, user=database_user,
                                password=database_password, host=database_host, port=database_port)
        self.cursor = self.conn.cursor()

    def insert_data(self, table, value):
        sql = "INSERT INTO %s VALUES %s" % (table, value)
        self.cursor.execute(sql)
        self.conn.commit()

    def close(self):
        self.conn.close()

posgre_insert = Progresql_Conn()


print("1 / 6 Start to insert Basic tables...\n")
time.sleep(0.1)
# 1 Create Basic tables

# hubexperiment
posgre_insert.insert_data('hubexperiment',(hash('experiment_2'), 'experiment_2', now(), 'PROJ.MP'))
# satexperiment
posgre_insert.insert_data("satexperiment",(hash('experiment_2'), now(), notnow(), "PROJ.MP", hash("Multimodal pre-autism"+"MRC"+"FOE"), "Multimodal pre-autism", "MRC", "FOE"))
# hubmeasurement
posgre_insert.insert_data("hubmeasurement",(hash('measurement_1'), 'measurement_1', now(), "PROJ.MP.EEG_Data"))
posgre_insert.insert_data("hubmeasurement",(hash('measurement_2'), 'measurement_2', now(), "PROJ.MP.fNIRS_Data"))
# linkmeasurementexp
posgre_insert.insert_data("linkmeasurementexp",(hash(hash('experiment_2')+hash('measurement_1')), hash('experiment_2'), hash('measurement_1'), now(), "PROJ.MP.EEG_Data"))
posgre_insert.insert_data("linkmeasurementexp",(hash(hash('experiment_2')+hash('measurement_2')), hash('experiment_2'), hash('measurement_2'), now(), "PROJ.MP.fNIRS_Data"))
# satmeasurement
posgre_insert.insert_data("satmeasurement",(hash('measurement_1'), now(), notnow(), "PROJ.MP.EEG_Data",hash("EEG" + "A neuroimaging modality that senses the electrical activity of the firing neurons") ,"EEG", "A neuroimaging modality that senses the electrical activity of the firing neurons"))
posgre_insert.insert_data("satmeasurement",(hash('measurement_2'), now(), notnow(), "PROJ.MP.fNIRS_Data",hash("fNIRS" + "An optical neuroimaging modality to monitor brain hemodynamics") ,"fNIRS", "An optical neuroimaging modality to monitor brain hemodynamics"))
# hubsession
posgre_insert.insert_data("hubsession",(hash('session_1'), 'session_1', now(), "PROJ.MP"))
posgre_insert.insert_data("hubsession",(hash('session_2'), 'session_2', now(), "PROJ.MP"))
# satsession
posgre_insert.insert_data('satsession',(hash('session_1'), now(), notnow(), 'PROJ.MP', hash('normal conversation' + 'Normal conversation without syllables'),  'normal conversation' , 'Normal conversation without syllables.'))
posgre_insert.insert_data('satsession',(hash('session_2'), now(), notnow(), 'PROJ.MP', hash('stressed conversation' + 'Stressed conversation condition that included syllables such as ‘na’, ‘ka’, ‘ta’, or ‘a’ that the subjects were instructed to mention sporadically throughout the duration of the session.'), 'stressed conversation', 'Stressed conversation condition that included syllables such as ‘na’, ‘ka’, ‘ta’, or ‘a’ that the subjects were instructed to mention sporadically throughout the duration of the session.'))
# linksessionexp
posgre_insert.insert_data("linksessionexp",( hash(hash('experiment_2')+hash('session_1')), hash('experiment_2'), hash('session_1'), now(), "PROJ.MP"))
posgre_insert.insert_data("linksessionexp",( hash(hash('experiment_2')+hash('session_2')), hash('experiment_2'), hash('session_2'), now(), "PROJ.MP"))
# hubfactor
posgre_insert.insert_data("hubfactor",(hash('fNIRS_Wavelength_1'), 'fNIRS_Wavelength_1', now(), "PROJ.MP"))
posgre_insert.insert_data("hubfactor",(hash('fNIRS_Wavelength_2'), 'fNIRS_Wavelength_2', now(), "PROJ.MP"))
posgre_insert.insert_data("hubfactor",(hash('EEG_Channel'), 'EEG_Channel', now(), "PROJ.MP"))
# satfactor
posgre_insert.insert_data("satfactor",(hash('fNIRS_Wavelength_1'), now(), notnow(), "PROJ.MP", hash("fNIRS" + "nm" + "760") ,"fNIRS" ,"nm" , "760"))
posgre_insert.insert_data("satfactor",(hash('fNIRS_Wavelength_2'), now(), notnow(), "PROJ.MP", hash("fNIRS" + "nm" + "850") ,"fNIRS" ,"nm" , "850"))
posgre_insert.insert_data("satfactor",(hash('EEG_Channel'), now(), notnow(), "PROJ.MP", hash("EEG" + "num" + "29") ,"EEG" ,"num" , "29"))


print("2 / 6 Start to insert Subjects & Units & Metadata of Subjects...\n")
time.sleep(0.1)
# 2 Handle each .inf file in every fold of fnirs_path

# fNIRS
for i,j,k in tqdm(os.walk(fnirs_path)):
    for kk in k:
        if '.inf' in kk:
            #Autism0001
            ind_subject = int(i.split('Autism')[-1][:4])
            #1raSessionDR
            ind_session = int(i.split('fNIRS-Data/')[-1][:1])
            df = pd.read_table(i + '/' + kk, sep='=', encoding='latin_1')
            df = df.fillna('null')
            if "Comtrol" in df.loc['Name'].values[0]:
                df.loc['Name'].values[0] = df.loc['Name'].values[0].replace("Comtrol", "Control")

            # Create subject just follow the .inf file in session 1 (nums = 43)
            if ind_session == 1:
                # hubsubject
                posgre_insert.insert_data("hubsubject", (hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower()),
                                                        df.loc['Name'].values.tolist()[0].split('-')[0].lower(),
                                                         now(),
                                                         "PROJ.MP"  + i.split(project_file_name)[-1].replace('/', '.').replace('-', '_')))

                # satsubject
                posgre_insert.insert_data("satsubject", ( hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower()),
                                                         now(),
                                                         notnow(),
                                                         "PROJ.MP" + (i + "/" + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_'),
                                                         hash(df.loc['Name'].values.tolist()[0].split('-')[0]+df.loc['Age'].values.tolist()[0]+df.loc['Gender'].values.tolist()[0]+df.loc['Additional Notes'].values.tolist()[0].replace("'", "")),
                                                         df.loc['Name'].values.tolist()[0].split('-')[0],
                                                         df.loc['Age'].values.tolist()[0],
                                                         df.loc['Gender'].values.tolist()[0],
                                                         df.loc['Additional Notes'].values.tolist()[0].replace("'", "")))

                # linksubjectexp
                posgre_insert.insert_data("linksubjectexp", (hash(hash('experiment_2') + hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower())), hash('experiment_2'), hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower()),  now(), "PROJ.MP"  + i.split(project_file_name)[-1].replace('/', '.')))

            # follow the .inf file to create experiment unit
            # hubexperimentunit
            posgre_insert.insert_data("hubexperimentunit", (hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session)),
                                                            df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session),
                                                            now(),
                                                            "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_')))

            # linkexperimentunit
            posgre_insert.insert_data("linkexperimentunit", (hash(hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session)) + hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session)) + hash('session_' + str(ind_session))),
                                                            hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session)),
                                                            hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower()),
                                                            hash('session_' + str(ind_session)),
                                                            now(),
                                                            "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('/','.').replace('-', '_')
                                                            ))

            for eachrow in df.iterrows():
                #print(eachrow[0], eachrow[1].values.tolist()[0])

                col = df.columns.to_list()[0].replace('[', '').replace(']', '')

                # hubmetadata inf
                posgre_insert.insert_data("hubmetadata", (hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session) + '_' + col + '_' + eachrow[0]),
                                                          df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session) + '_' + col + '_' + eachrow[0],
                                                          now(),
                                                          "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_')))

                # linkunitmeta
                posgre_insert.insert_data("linkunitmeta", (hash(hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session)) + hash('measurement_2') + hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session) + '_' + col + '_' + eachrow[0])),
                                                           hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session)),
                                                           hash('measurement_2'),
                                                           hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session) + '_' + col + '_' + eachrow[0]),
                                                           now(),
                                                           "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_')))

                # satmetadata
                posgre_insert.insert_data("satmetadata", (hash(df.loc['Name'].values.tolist()[0].split('-')[0].lower() + '_' + str(ind_session) + '_' + col + '_' + eachrow[0]),
                                                          now(),
                                                          notnow(),
                                                          'PROJ.MP' + (i + '/' + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_'),
                                                          hash(col + '_' + eachrow[0] + eachrow[1].values.tolist()[0]),
                                                          col + '_' + eachrow[0],
                                                          eachrow[1].values.tolist()[0].replace("'","")))

print("3 / 6 Start to insert fNIRS Data of .wl...\n")
time.sleep(0.1)
# 3 Handle each .wl1 .wl2 file in every fold of fnirs_path
# Process and insert them into hubdata

# fNIRS-wl
for i, j, k in tqdm(os.walk(fnirs_path)):
    for kk in k:
        if '.wl' in kk:
            #Autism0001
            ind_subject = int(i.split('Autism')[-1][:4])
            #1raSessionDR
            ind_session = int(i.split('fNIRS-Data/')[-1][:1])
            #factor
            factor = int(kk[-1])

            file = open(i + '/' + kk, "r").read()
            
            # hubdata
            posgre_insert.insert_data("hubdata", (hash(kk[-3:] + '_' + str(ind_subject) + '_' + str(ind_session)),
                                                     kk[-3:] + '_' + str(ind_subject) + '_' + str(ind_session),
                                                     now(),
                                                     "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace(
                                                         '/', '.').replace('-', '_')
            ))
            # satdata
            posgre_insert.insert_data("satdata", (hash(kk[-3:] + '_' + str(ind_subject) + '_' + str(ind_session)),
                                                    now(),
                                                    notnow(),
                                                     "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace(
                                                         '/', '.').replace('-', '_'),
                                                    hash(binascii.b2a_hex(file.encode('utf-8')).decode('utf-8') + 'binascii.b2a_hex'),
                                                    binascii.b2a_hex(file.encode('utf-8')).decode('utf-8'),
                                                    'binascii.b2a_hex'
            ))
            
            # linkdata
            posgre_insert.insert_data("linkdata", (hash(hash('fNIRS_Wavelength_' + str(factor)) + hash('measurement_2') + hash('control' + '{:0>3d}'.format(ind_subject) + '_' + str(ind_session)) + hash(kk[-3:] + '_' + str(ind_subject) + '_' + str(ind_session))),
                                                   hash('fNIRS_Wavelength_' + str(factor)),
                                                   hash('measurement_2'),
                                                   hash('control' + '{:0>3d}'.format(ind_subject) + '_' + str(ind_session)),
                                                   hash(kk[-3:] + '_' + str(ind_subject) + '_' + str(ind_session)),
                                                   now(),
                                                   "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace(
                                                      '/', '.').replace('-', '_')
            ))


print("4 / 6 Start to insert fNIRS Data of .dat... & b1.dat\n")
time.sleep(0.1)
# 4 Handle each .dat b1.dat file in every fold of fnirs_path
# Process and insert them into hubdata

# fNIRS-dat
for i, j, k in tqdm(os.walk(fnirs_path)):
    for kk in k:
        if '.dat' in kk:
            # Autism000
            ind_subject = int(i.split('Autism')[-1][:4])
            # 1raSessionDR
            ind_session = int(i.split('fNIRS-Data/')[-1][:1])

            file = open(i + '/' + kk, "rb").read()
            if 'b1.dat' in kk:
                added = 'b1.'
            else:
                added = ''
            last = kk[-7:]

            # hubprocesseddata
            posgre_insert.insert_data("hubprocesseddata", (hash(added + kk[-3:] + '_' + str(ind_subject) + '_' + str(ind_session) + '_' + last),
                                                           added + kk[-3:] + '_' + str(ind_subject) + '_' + str(ind_session) + '_' + last,
                                                           now(),
                                                           "PROJ.MP" + (i + '/' + kk).split(project_file_name)[
                                                               -1].replace(
                                                               '/', '.').replace('-', '_')
            ))

            # satprocesseddata
            posgre_insert.insert_data("satprocesseddata", (hash(added + kk[-3:] + '_' + str(ind_subject) + '_' + str(ind_session) + '_' + last),
                                                           now(),
                                                           notnow(),
                                                           "PROJ.MP" + (i + '/' + kk).split(project_file_name)[
                                                               -1].replace(
                                                               '/', '.').replace('-', '_'),
                                                           hash(binascii.b2a_hex(file).decode('utf-8') + 'binascii.b2a_hex'),
                                                           binascii.b2a_hex(file).decode('utf-8'),
                                                           'binascii.b2a_hex'
            ))

            for factor in range(1,3):
            # linkdatapro
                posgre_insert.insert_data("linkdatapro", (hash(hash('wl' + str(factor) + '_' + str(ind_subject) + '_' + str(ind_session)) + hash(added + kk[-3:] + '_' + str(ind_subject) + '_' + str(ind_session) + '_' + last)),
                                                               hash('wl' + str(factor) + '_' + str(ind_subject) + '_' + str(ind_session)),
                                                               hash(added + kk[-3:] + '_' + str(ind_subject) + '_' + str(ind_session) + '_' + last),
                                                               now(),
                                                               "PROJ.MP" + (i + '/' + kk).split(project_file_name)[
                                                                   -1].replace(
                                                                   '/', '.').replace('-', '_')
                ))

print("5 / 6 Start to insert EEG Data of .mat...\n")
time.sleep(0.1)
# 5 Handle each .mat file in the fold of egg_path
# Process and insert them into hubdata

# EEG-mat
for i, j, k in os.walk(egg_path):
    for kk in tqdm(k):

        if '.mat' in kk:
            # Autism0001
            control = kk.split('-')[0].lower()
            # 1raSessionDR
            ind_session = int(kk.split('-')[1].split('.')[0].replace('P', ''))

            file = h5py.File(i + '/' + kk, 'r')["Data"][:].T.copy()

            if '-1-1.mat' in kk:
                last = '_1'
            else:
                last = ''

            for c in range(file.shape[0]):

                # hubdata
                posgre_insert.insert_data("hubdata", (
                hash('mat_' + str(int(control[-3:])) + '_' + str(ind_session) + last + '_c' + str(c+1)),
                'mat_' + str(int(control[-3:])) + '_' + str(ind_session) + last + '_c' + str(c+1),
                now(),
                "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('//', '.').replace('/','.').replace('-', '_')
                ))

                # satdata
                posgre_insert.insert_data("satdata", (hash('mat_' + str(int(control[-3:])) + '_' + str(ind_session) + last + '_c' + str(c+1)),
                now(),
                notnow(),
                "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('//', '.').replace('/','.').replace('-', '_'),
                hash(binascii.b2a_hex(file[c,:]).decode('utf-8') + 'binascii.b2a_hex'),
                binascii.b2a_hex(file[c,:]).decode('utf-8'),
                'binascii.b2a_hex'
                ))

                # linkdata
                posgre_insert.insert_data("linkdata", (hash(hash('EEG_Channel') + hash('measurement_1') + hash(control + '_' + str(ind_session)) + hash('mat_' + str(int(control[-3:])) + '_' + str(ind_session) + last + '_c' + str(c+1))),
                                                       hash('EEG_Channel'),
                                                       hash('measurement_1'),
                                                       hash(control + '_' + str(ind_session)),
                                                       hash('mat_' + str(int(control[-3:])) + '_' + str(ind_session) + last + '_c' + str(c+1)),
                                                       now(),
                                                       "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('//', '.').replace('/', '.').replace('-','_')
                                                       ))

print("6 / 6 Start to insert fNIRS Data of Meta...\n")
time.sleep(0.1)
# 6 Handle each .hdr config.txt file in the fold of fnirs_path
# Process and insert them into hubmetadata

# fNIRS-Meta
for i, j, k in tqdm(os.walk(fnirs_path)):
    for kk in k:
        if '.hdr' in kk:
            # Autism0001
            ind_subject = int(i.split('Autism')[-1][:4])
            # 1raSessionDR
            ind_session = int(i.split('fNIRS-Data/')[-1][:1])

            control = 'control{:0>3d}_'.format(ind_subject) + str(ind_session)

            df = pd.read_table(i + '/' + kk, sep='=', encoding='latin_1')
            df = df.fillna('null')

            col = df.columns.to_list()[0].replace('[', '').replace(']', '')
            for eachrow in df.iterrows():
                if '[' in eachrow[0]:
                    col = eachrow[0].replace('[', '').replace(']', '')
                else:
                    # hubmetadata inf
                    posgre_insert.insert_data("hubmetadata", (hash(control + '_' + col + '_' + eachrow[0]),
                                                              control + '_' + col + '_' + eachrow[0],
                                                              now(),
                                                              "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_')))

                    # linkunitmeta
                    posgre_insert.insert_data("linkunitmeta", (hash(hash(control) + hash('measurement_2') + hash(control + '_' + col + '_' + eachrow[0])),
                                                               hash(control),
                                                               hash('measurement_2'),
                                                               hash(control + '_' + col + '_' + eachrow[0]),
                                                               now(),
                                                               "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_')))

                    # satmetadata
                    posgre_insert.insert_data("satmetadata", (hash(control + '_' + col + '_' + eachrow[0]),
                                                              now(),
                                                              notnow(),
                                                              'PROJ.MP' + (i + '/' + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_'),
                                                              hash(col + '_' + eachrow[0] + eachrow[1].values.tolist()[0].replace("'", "")),
                                                              col + '_' + eachrow[0],
                                                              eachrow[1].values.tolist()[0].replace("'", "")))

        if 'config.txt' in kk:
            # Autism0001
            ind_subject = int(i.split('Autism')[-1][:4])
            # 1raSessionDR
            ind_session = int(i.split('fNIRS-Data/')[-1][:1])

            control = 'control{:0>3d}_'.format(ind_subject) + str(ind_session)

            df = pd.read_table(i + '/' + kk, sep='=', encoding='latin_1', header=None)
            df = df.fillna('null')
            df.iloc[8,1] = df.iloc[8,1] + df.iloc[9,0]
            df.drop(axis=0,index=9,inplace=True)

            col = 'Config'

            for eachrow in df.iterrows():
                # hubmetadata inf
                posgre_insert.insert_data("hubmetadata", (hash(control + '_' + col + '_' + eachrow[1].loc[0].replace('_','')),
                                                          control + '_' + col + '_' + eachrow[1].loc[0].replace('_',''),
                                                          now(),
                                                          "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_')
                ))

                # linkunitmeta
                posgre_insert.insert_data("linkunitmeta", (hash(hash(control) + hash('measurement_2') + hash(control + '_' + col + '_' + eachrow[1].loc[0].replace('_',''))),
                                                            hash(control),
                                                            hash('measurement_2'),
                                                            hash(control + '_' + col + '_' + eachrow[1].loc[0].replace('_','')),
                                                            now(),
                                                            "PROJ.MP" + (i + '/' + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_')
                ))

                # satmetadata
                posgre_insert.insert_data("satmetadata", (hash(control + '_' + col + '_' + eachrow[1].loc[0].replace('_','')),
                                                          now(),
                                                          notnow(),
                                                          'PROJ.MP' + (i + '/' + kk).split(project_file_name)[-1].replace('/', '.').replace('-', '_'),
                                                          hash(col + '_' + eachrow[1].loc[0].replace('_','') +  eachrow[1].loc[1].replace("'", "")),
                                                          col + '_' + eachrow[1].loc[0].replace('_',''),
                                                          eachrow[1].loc[1].replace("'", "")
                ))

