# Author: Wenhao Li

# process and insert the data of Visuomotor functional connectivity into data vualt

# Find config.ini
import os
import configparser
cf = configparser.ConfigParser()
cf.read(os.path.dirname(os.getcwd()) + '/' + 'config.ini')

# ↓ -----CONFIG----- ↓
data_path=cf.get('Path','vm_path')
database="datavault_smd_sp_g01"
user=cf.get('Postgresql','database_user')
password=cf.get('Postgresql','database_password')
host=cf.get('Postgresql','database_host')
port=cf.get('Postgresql','database_port')
# ↑ -----CONFIG----- ↑

import hashlib
import psycopg2
import pandas as pd
import os
import pickle
import time

#Used to get the names of all files under a directory and store them in a list
file_list=[]
for root, dirs, files in os.walk(data_path):
    file_list=files
def path(i):
    filepath=os.path.join(data_path,file_list[i])
    return filepath

def f(c):
    '''
    Args:Handling of data with file name exceptions when reading files
        c:file name

    Returns:correct file name

    '''
    f=c.split('_')
    if len(f[0])<6:
        str=c.replace('VM010','VM0010')
        return str
    else:
        return c
m=len(file_list)

#Used to store database names


#Create a class for database connection and insert operations
class Database_insert:
    def __init__(self):
        self.conn = psycopg2.connect(database=database, user=user, password=password, host=host, port=port)
        self.cursor = self.conn.cursor()

    def insert_data(self, table, value):
        sql = "INSERT INTO %s VALUES %s" % (table, value)
        self.cursor.execute(sql)
        self.conn.commit()

    def close(self):
        self.conn.close()
#The actual runtime situation is that the class cannot be inserted, so the db_input function is called to do so
def db_input(sql,value):

    db = psycopg2.connect(database=database, user=user, password=password, host=host, port=port)
    cursor = db.cursor()
    cursor.execute(sql, value)
    db.commit()
    cursor.close()


def metadata(no):
    '''
    Args:Reading of metadata
        no: Receiving Document Number
    Returns:Corresponding metadata
    '''
    f = open(path(no))
    metadata = f.readlines()[:32]
    for i in range(len(metadata)):
        metadata[i]=metadata[i].replace('\n','')
    for i in range(len(metadata)):
        metadata[i] = metadata[i].split(',')
    return metadata
def data_pre_processing(no):
    '''
    Args:Pre-processing of data and then conversion to binary files
        no: Receiving Document Number

    Returns:Corresponding binary file

    '''
    f = open(path(no))
    data = f.readlines()[40:]
    for i in range(len(data)):
        data[i] = data[i].replace('\n', '')
    for i in range(len(data)):
        data[i] = data[i].replace('E', '')
    for i in range(len(data)):
        data[i] = data[i].split(',')
        if len(data[i]) < 30:
            add = ['0', '0', '0']
            data[i] += add
    title = data[0]
    sp_data = pd.DataFrame(data[1:])
    sp_data.columns = title
    pro_data = pickle.dumps(sp_data)
    return pro_data
def metadata_dict(i):
    '''

    Args:Processing of metadata and extraction of metadata using nested dictionaries
        i:Receiving Document Number

    Returns:corresponding nested dictionaries

    '''
    data = pd.read_table(path(i))
    metadata_dict = {}
    value_dict = {}
    type = ['header', '', '', '']
    j = 1
    for i in range(0, 26):
        if len(data.iat[i, 0].split(',')) == 1:
            type[j] = data.iat[i, 0]
            j += 1
            continue
        else:
            input1 = data.iat[i, 0].split(',')
            if len(input1) == 2:
                value_dict[input1[0]] = input1[1]
            else:
                pro_input1 = input1[1:]
                if '' in pro_input1:
                    pro_input1.remove('')
                value_dict[input1[0]] = pro_input1
    stim = data.iat[27, 0].split(',')
    stim_1 = []
    stim_2 = []
    for k in range(len(stim)):
        if k % 2 == 0:
            stim_1.append(stim[k])
        else:
            stim_2.append(stim[k])
    dict_stim = dict(zip(stim_1, stim_2))
    value_dict[data.iat[26, 0].split(',')[0]] = dict(dict_stim)
    value_dict[data.iat[28, 0].split(',')[0]] = data.iat[28, 0].split(',')[1]
    value_dict[data.iat[29, 0].split(',')[0]] = data.iat[29, 0].split(',')[1:]
    list1 = list(value_dict.keys())
    list2 = list(value_dict.values())
    version = {}
    version[list1[0]] = list2[0]
    metadata_dict[type[0]] = dict(version)
    metadata_dict[type[1]] = dict(zip(list1[1:6], list2[1:6]))
    metadata_dict[type[2]] = dict(zip(list1[6:15], list2[6:15]))
    metadata_dict[type[3]] = dict(zip(list1[15:], list2[15:]))
    return metadata_dict
def check(no):
    '''

    Args:Separate extraction of file names
        no: Receiving Document Number

    Returns:List after file name separation

    '''
    file_name_split=f(file_list[no]).split('_')
    return file_name_split
def hashkey_generation(hash_str):
    '''

    Args:Generate hashkey
        hash_str:Fields to be hashed

    Returns:The hashkey obtained after processing

    '''
    sha1=hashlib.sha1(hash_str.encode())
    return sha1.hexdigest()
def now():
    '''

    Returns:local time

    '''
    t=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    return t
def notnow():
    '''

    Returns:loadenddate

    '''
    return '9999-12-31 24:00:00'

'''Data insertion for hub
where hash_id is the value of the field to be processed and no is the document serial number'''
posgre_insert = Database_insert()
def hubexperiment():
    posgre_insert.insert_data('hubexperiment',(hashkey_generation('experiment_1'), 'experiment_1', now(), "PROJ.VFC"))
def hubsubject(hash_id,no):
    posgre_insert.insert_data('hubsubject',(hashkey_generation(hash_id), check(no)[0], now(), "PROJ.VFC"))
def hubmetadata(hash_id):
    posgre_insert.insert_data('hubmetadata',(hashkey_generation(hash_id), hash_id, now(), "PROJ.VFC"))
def hubmeasurement(hash_id,no):
    posgre_insert.insert_data('hubmeasurement',(hashkey_generation(hash_id), f(file_list[no]).replace('.csv',''), now(), "PROJ.VFC"))
def hubsession(hash_id,no):
    posgre_insert.insert_data('hubsession', (hashkey_generation(hash_id), check(no)[0]+'_'+check(no)[1], now(), 'PROJ.VFC'))
def hubexperimentunit(hash_id,no):
    posgre_insert.insert_data('hubexperimentunit', (hashkey_generation(hash_id),f(file_list[no]).replace('.csv',''), now(), "PROJ.VFC."+file_list[no]))
def hubfactor(hash_id,no):
    posgre_insert.insert_data('hubfactor', (hashkey_generation(hash_id), check(no)[0]+'_'+check(no)[1], now(), 'PROJ.VFC'))
def hubdata(hash_id,no):
    posgre_insert.insert_data('hubdata', (hashkey_generation(hash_id), f(file_list[no]).replace('.csv',''), now(), 'PROJ.VFC.'+file_list[no]))
def hubprocessseddata(hash_id,no):
    posgre_insert.insert_data('hubprocessseddata', (hashkey_generation(hash_id), f(file_list[no]).replace('.csv',''), now(), 'PROJ.VFC.'+file_list[no]))

def detail(act,i):
    '''

    Args:For obtaining detailed information
        act:Operation serial number
        i:Document serial number

    Returns:

    '''
    if act==1:
        if check(i)[2]=='HBA':
            return (check(i)[2]+'_'+check(i)[3]+'_'+check(i)[4].replace('.csv',''))
        elif check(i)[2]=='MES':
            return (check(i)[2]+'_'+check(i)[3].replace('.csv',''))
    elif act==2:
        if check(i)[2]=='HBA':
            if check(i)[4].replace('.csv','')=='Deoxy':
                return 'deoxy-haemoglobin'
            if check(i)[4].replace('.csv','')=='Oxy':
                return 'oxy-haemoglobin'
            if check(i)[4].replace('.csv','')=='Total':
                return 'oxy- and deoxy-haemoglobin'
        elif check(i)[2]=='MES':
            return 'MES'
def hashdiff(str):
    return hashkey_generation(str)

'''Data insertion for sat
where hash_id is the value of the field to be processed and no is the document serial number'''
def satexperiment():
    hash=hashkey_generation('experiment_1')
    st='Visuomotor functional connectivity'+'FOE'+'Imperial College'
    posgre_insert.insert_data('satexperiment', (hash, now(), notnow(), 'PROJ.VFC',hashdiff(st), 'Visuomotor functional connectivity','FOE','Imperial College'))
def satmetadata(hash_id,k,v):
    hash=hashkey_generation(hash_id)
    st = k+v
    posgre_insert.insert_data('satmetadata', (hash, now(),notnow(), 'PROJ.VFC',hashdiff(st),k,v))
def satmeasurement(hash_id,no):
    hash=hashkey_generation(hash_id)
    str = detail(1,no) +detail(2,no)
    posgre_insert.insert_data('satmeasurement', (hash, now(),notnow(), 'PROJ.VFC', hashdiff(str),detail(1,no),detail(2,no)))
def satprocesseddate(hash_id,no):
    hash=hashkey_generation(hash_id)
    st = str(data_pre_processing(no))+ 'python'
    posgre_insert.insert_data('satprocesseddate', (hashkey_generation(hash), now(),notnow(), 'PROJ.VFC.'+file_list[no], hashdiff(st),data_pre_processing(no),'python'))
def satsubject(hash_id,no):
    hash= hashkey_generation(hash_id)
    str = metadata(no)[4][1]+','+metadata(no)[6][1]+','+metadata(no)[7][1]+','+metadata(no)[5][1]+','+metadata(no)[5][2]
    posgre_insert.insert_data('satsubject', (hash, now(),notnow(), 'PROJ.VFC', hashdiff(str),metadata(no)[4][1],metadata(no)[6][1],metadata(no)[7][1],metadata(1)[5][1]+','+metadata(1)[5][2]))
def sessiondetial(i):
    if check(i)[1]=='Moto':
        return 'Motor Stimulus Only'
    elif check(i)[1]=='Rest':
        return 'Rest'
    elif check(i)[1]=='ViMo':
        return 'VisuoMotor Task'
    elif check(i)[1]=='Viso':
        return 'Visual Stimulus Only'
def satsession(hash_id,no):
    hash= hashkey_generation(hash_id)
    str = check(no)[1]+sessiondetial(no)
    posgre_insert.insert_data('satsession', (hash, now(),notnow(), 'PROJ.VFC', hashdiff(str),check(no)[1],sessiondetial(no)))
def satfactor(hash_id,no):
    hash= hashkey_generation(hash_id)
    st = check(no)[0]+'_'+check(no)[1]+'metadata'
    posgre_insert.insert_data('satfactor', (hash, now(),notnow(), 'PROJ.VFC.'+file_list[no], hashdiff(st),check(no)[0]+'_'+check(no)[1],'metadata'))
def satdata(hash_id,no):
    hash = hashkey_generation(hash_id)
    st = str(data_pre_processing(no)) + 'dataframe-->pickle.dumps()'
    value=(hash, now(),notnow(), 'PROJ.VFC.'+file_list[no], hashdiff(st),data_pre_processing(no),'dataframe->pickle.dumps()')
    sql='insert into satdata values(%s,%s,%s,%s,%s,%s,%s)'
    db_input(sql,value)
'''link '''
'''Data insertion for link'''
def linksubjectexp(hash_id):
    hash= str(hashkey_generation('experiment_1'))+str(hashkey_generation(hash_id))
    posgre_insert.insert_data('linksubjectexp', (hashkey_generation(hash),hashkey_generation('experiment_1'),hashkey_generation(hash_id), now(), 'PROJ.VFC'))
def linksubjectmeta(hash_id,metahash,no):
    hash= str(hashkey_generation(hash_id))+str(hashkey_generation(metahash))
    posgre_insert.insert_data('linksubjectmeta', (hashkey_generation(hash),hashkey_generation(check(no)[0]),hashkey_generation(metahash), now(), 'PROJ.VFC'))
def linkunitmeta(hash_id1,hash_id2,hash_id3, no):
    hash= str(hashkey_generation(hash_id1)) + str(hashkey_generation(hash_id2)) + str(hashkey_generation(hash_id3))
    posgre_insert.insert_data('linkunitmeta', (hashkey_generation(hash),hashkey_generation(hash_id1),hashkey_generation(hash_id2) , hashkey_generation(hash_id3) , now(), 'PROJ.VFC.'+file_list[no]))
def linkmeasurementexp(hash_id):
    hash= str(hashkey_generation('experiment_1'))+str(hashkey_generation(hash_id))
    posgre_insert.insert_data('linkmeasurementexp', (hashkey_generation(hash),hashkey_generation('experiment_1'),hashkey_generation(hash_id), now(), 'PROJ.VFC'))
def linksessionexp(hash_id):
    hash= str(hashkey_generation('experiment_1'))+str(hashkey_generation(hash_id))
    posgre_insert.insert_data('linksessionexp', (hashkey_generation(hash),hashkey_generation('experiment_1'),hashkey_generation(hash_id), now(), 'PROJ.VFC'))
def linkdata(hash_id1,hash_id2,hash_id3,hash_id4, no):
    hash= str(hashkey_generation(hash_id1)) + str(hashkey_generation(hash_id2)) + str(hashkey_generation(hash_id3)) + str(hashkey_generation(hash_id4))
    posgre_insert.insert_data('linkdata', (hashkey_generation(hash),hashkey_generation(hash_id1),hashkey_generation(hash_id2) , hashkey_generation(hash_id3) , hashkey_generation(hash_id4), now(), 'PROJ.VFC.'+file_list[no]))
def linkexperimentunit(hash_id1,hash_id2,hash_id3):
    hash= str(hashkey_generation(hash_id1)) + str(hashkey_generation(hash_id2)) + str(hashkey_generation(hash_id3))
    posgre_insert.insert_data('linkexperimentunit', (hashkey_generation(hash),hashkey_generation(hash_id1),hashkey_generation(hash_id2) , hashkey_generation(hash_id3) , now(), 'PROJ.VFC'))
def linkdatapro(hash_id):
    hash= str(hashkey_generation(hash_id)) + str(hashkey_generation(hash_id))
    posgre_insert.insert_data('linkdatapro', (hashkey_generation(hash),hashkey_generation(hash_id) , hashkey_generation(hash_id), now(), 'PROJ.VFC'))
def hash(no,i):
    if i ==1:
        hash1 = check(no)[0]+'_'+check(no)[1]
        return hash1
    if i ==2:
        if check(no)[2]=='HBA':
            hash2 = check(no)[-3]+'_'+check(no)[-2]+'_'+check(no)[-1].replace('.csv','')
            return hash2
        elif check(no)[2]=='MES':
            hash2 = check(no)[-2] + '_' + check(no)[-1].replace('.csv','')
            return hash2

#metadata input
def metadata_input(hash_id,i):
    d = metadata_dict(i)
    k1 = list(d.keys())
    for key1 in k1:
        if key1 =='header':
            hubhash=hash_id+'_'+key1
            k=hubhash+'_'+list(d[key1].keys())[0]
            v=list(d[key1].values())[0]
            hubmetadata(k)
            satmetadata(k, k, v)
        if key1 =='Patient Information':
            hubhash = hash_id + '_' + 'Patient'
            k2=list(d[key1].keys())
            for key2 in k2:
                k=hubhash+'_'+key2
                if key2=='Comment':
                    v=','.join(d[key1][key2])
                else:
                    v =d[key1][key2]
                hubmetadata(k)
                satmetadata(k, k, v)
        if key1 =='Analyze Information':
            hubhash = hash_id + '_' + 'Analyze'
            for key3 in list(d[key1].keys()):
                k=hubhash+'_'+key3
                v=d[key1][key3]
                hubmetadata(k)
                satmetadata(k, k, v)
        if key1 =='Measure Information':
            hubhash = hash_id + '_' + 'Measure'
            key4=list(d[key1].keys())
            for j in key4:
                if j =='Date':
                    v = d[key1][j].replace('/', '-')
                elif j == 'Wave[nm]':
                    v = ','.join(d[key1][j])
                elif j== 'Wave Length':
                    v = ','.join(d[key1][j])
                elif j == 'Analog Gain':
                    v = ','.join(d[key1][j])
                elif j == 'Digital Gain':
                    v = ','.join(d[key1][j])
                elif j == 'Stim Time[s]':
                    v = ''
                    for n in d[key1][j]:
                        v = v + n + ':' + d[key1][j][n] + ','
                    v=v[:-1]
                elif j == 'Exception Ch':
                    v = ','.join(d[key1][j])
                else:
                    v = d[key1][j]
                k = hubhash + '_' + j
                if len(k)>40:
                    print(k)
                hubmetadata(k)
                satmetadata(k, k, v)

def f1():
    hubexperiment()
    satexperiment()
    print(1)
#experimentunit,data,satdata
def f2():
    for i in range(m):
        hubexperimentunit(f(file_list[i]).replace('.csv',''),i)
        hubdata(f(file_list[i]),i)
        satdata(f(file_list[i]),i)
    print(2)

#subject  satsubject link exp sub
def f3():
    list3=[]
    for i in range(m):
        if check(i)[0] not in list3 :
            list3.append(check(i)[0])
            hubsubject(check(i)[0],i)
            satsubject(check(i)[0],i)
            linksubjectexp(check(i)[0])
        else:
            continue
    print(3)
#meatadata,sat, factor,sat
def f4():
    list4=[]
    for i in range(m):
        if hash(i,1) not in list4:
            list4.append(hash(i,1))
            metadata_input(hash(i,1), i)
            hubfactor(hash(i,1),i)
            satfactor(hash(i,1),i)

        else:
            continue
    print(4)


#session,sat
def f5():
    se_a=1
    list5=[]
    for i in range(m):
        if check(i)[1] not in list5 and se_a<=4:
            list5.append(check(i)[1])
            hubsession(check(i)[1],i)
            satsession(check(i)[1],i)
            linksessionexp(check(i)[1])
            se_a+=1
        elif se_a >4:
            break
    print(5)

#measure,sat
def f6():
    me_a=1
    list6=[]
    for i in range(m):
        if check(i)[-1].replace('.csv','') not in list6 and me_a<=4:
            list6.append(check(i)[-1].replace('.csv',''))
            hubmeasurement(hash(i,2),i)
            satmeasurement(hash(i,2),i)
            linkmeasurementexp(hash(i,2))
            me_a += 1
        elif me_a>4:
            break
    print(6)
#link unit sub ses
def f7():
    for i in range(m):
        linkexperimentunit(f(file_list[i]).replace('.csv',''),check(i)[0],check(i)[1])
        linkdata(hash(i,1),hash(i,2),f(file_list[i]).replace('.csv',''),f(file_list[i]),i)

    print(7)

def f8():
    list8=[]
    for i in range(m):
        if hash(i,1) not in list8:
            list8.append(hash(i,1))
            d = metadata_dict(i)
            k1 = list(d.keys())
            for j in range(len(k1)):
                k2 = list(d[k1[j]].keys())
                for k in range(len(k2)):
                    metahash = hash(i, 1) + '_' + k1[j].split(' ')[0] + '_' + k2[k]
                    linksubjectmeta(check(i)[0],metahash, i)
    print(8)

def f9():
    for i in range(m):
        d = metadata_dict(i)
        k1 = list(d.keys())
        for j in range(len(k1)):
            k2=list(d[k1[j]].keys())
            for k in range(len(k2)):
                metahash=hash(i,1)+'_'+k1[j].split(' ')[0]+'_'+k2[k]
                linkunitmeta(f(file_list[i]).replace('.csv', ''), hash(i, 2), metahash, i)
    print(9)

f1()#Insert the data into the hubexperiment,satexperiment
f2()#Insert the data into the hubexperimentunit,hubdata,satdata
f3()#Insert the data into the hubsubject,satsubject,linksubjectexp
f4()#Insert the data into the hubmetadata,satmetadata,hubfactor,satfactor
f5()#Insert the data into the hubsession,satsession,linksessionexp
f6()#Insert the data into the hubmeasurement,satmeasurement,linkmeasurementexp
f7()#Insert the data into the linkexperimentunit,linkdata
f8()#Insert the data into the linksubjectmeta
f9()#Insert the data into the linkunitmeta'''







