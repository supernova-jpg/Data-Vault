# Author: Sheng Li

from django.db import models

# Create your models here.
class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=150)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    id = models.BigAutoField(primary_key=True)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.BooleanField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.BooleanField()
    is_active = models.BooleanField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.SmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    id = models.BigAutoField(primary_key=True)
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class Hubdata(models.Model):
    hashkeydata = models.CharField(primary_key=True, max_length=40)
    dataid = models.CharField(max_length=40, blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'hubdata'


class Hubexperiment(models.Model):
    hashkeyexperiment = models.CharField(primary_key=True, max_length=40)
    experimentid = models.CharField(max_length=40, blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'hubexperiment'


class Hubexperimentunit(models.Model):
    hashkeyexperimentunit = models.CharField(primary_key=True, max_length=40)
    experimentunitid = models.CharField(max_length=40, blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'hubexperimentunit'


class Hubfactor(models.Model):
    hashkeyfactor = models.CharField(primary_key=True, max_length=40)
    factorid = models.CharField(max_length=40, blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'hubfactor'


class Hubmeasurement(models.Model):
    hashkeymeasurement = models.CharField(primary_key=True, max_length=40)
    measurementid = models.CharField(max_length=40, blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'hubmeasurement'


class Hubmetadata(models.Model):
    hashkeymetadata = models.CharField(primary_key=True, max_length=40)
    metadtaid = models.CharField(max_length=80, blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'hubmetadata'


class Hubprocesseddata(models.Model):
    hashkeyprocesseddata = models.CharField(primary_key=True, max_length=40)
    processeddataid = models.CharField(max_length=40, blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=120, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'hubprocesseddata'


class Hubsession(models.Model):
    hashkeysession = models.CharField(primary_key=True, max_length=40)
    sessionid = models.CharField(max_length=40, blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'hubsession'


class Hubsubject(models.Model):
    hashkeysubject = models.CharField(primary_key=True, max_length=40)
    subjectid = models.CharField(max_length=40, blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'hubsubject'


class Linkdata(models.Model):
    hashkeylinkdata = models.CharField(primary_key=True, max_length=40)
    hashkeyfactor = models.ForeignKey(Hubfactor, models.DO_NOTHING, db_column='hashkeyfactor', blank=True, null=True)
    hashkeymeasurement = models.ForeignKey(Hubmeasurement, models.DO_NOTHING, db_column='hashkeymeasurement', blank=True, null=True)
    hashkeyexperimentunit = models.ForeignKey(Hubexperimentunit, models.DO_NOTHING, db_column='hashkeyexperimentunit', blank=True, null=True)
    hashkeydata = models.ForeignKey(Hubdata, models.DO_NOTHING, db_column='hashkeydata', blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'linkdata'


class Linkdatapro(models.Model):
    hashkeydatapro = models.CharField(primary_key=True, max_length=40)
    hashkeydata = models.ForeignKey(Hubdata, models.DO_NOTHING, db_column='hashkeydata', blank=True, null=True)
    hashkeyprocesseddata = models.ForeignKey(Hubprocesseddata, models.DO_NOTHING, db_column='hashkeyprocesseddata', blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'linkdatapro'


class Linkexperimentunit(models.Model):
    hashkeylinkexperimentunit = models.CharField(primary_key=True, max_length=40)
    hashkeyexperimentunit = models.ForeignKey(Hubexperimentunit, models.DO_NOTHING, db_column='hashkeyexperimentunit', blank=True, null=True)
    hashkeysubject = models.ForeignKey(Hubsubject, models.DO_NOTHING, db_column='hashkeysubject', blank=True, null=True)
    hashkeysession = models.ForeignKey(Hubsession, models.DO_NOTHING, db_column='hashkeysession', blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'linkexperimentunit'


class Linkmeasurementexp(models.Model):
    hashkeymeasurementexp = models.CharField(primary_key=True, max_length=40)
    hashkeyexperiment = models.ForeignKey(Hubexperiment, models.DO_NOTHING, db_column='hashkeyexperiment', blank=True, null=True)
    hashkeymeasurement = models.ForeignKey(Hubmeasurement, models.DO_NOTHING, db_column='hashkeymeasurement', blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'linkmeasurementexp'


class Linksessionexp(models.Model):
    hashkeysessionexp = models.CharField(primary_key=True, max_length=40)
    hashkeyexperiment = models.ForeignKey(Hubexperiment, models.DO_NOTHING, db_column='hashkeyexperiment', blank=True, null=True)
    hashkeysession = models.ForeignKey(Hubsession, models.DO_NOTHING, db_column='hashkeysession', blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'linksessionexp'


class Linksubjectexp(models.Model):
    hashkeytosubjectexp = models.CharField(primary_key=True, max_length=40)
    hashkeyexperiment = models.ForeignKey(Hubexperiment, models.DO_NOTHING, db_column='hashkeyexperiment', blank=True, null=True)
    hashkeysubject = models.ForeignKey(Hubsubject, models.DO_NOTHING, db_column='hashkeysubject', blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'linksubjectexp'


class Linksubjectmeta(models.Model):
    hashkeysubjectmeta = models.CharField(primary_key=True, max_length=40)
    hashkeysubject = models.ForeignKey(Hubsubject, models.DO_NOTHING, db_column='hashkeysubject', blank=True, null=True)
    hashkeymetadata = models.ForeignKey(Hubmetadata, models.DO_NOTHING, db_column='hashkeymetadata', blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'linksubjectmeta'


class Linkunitmeta(models.Model):
    hashkeyunitmeta = models.CharField(primary_key=True, max_length=40)
    hashkeyexperimentunit = models.ForeignKey(Hubexperimentunit, models.DO_NOTHING, db_column='hashkeyexperimentunit', blank=True, null=True)
    hashkeymeasurement = models.ForeignKey(Hubmeasurement, models.DO_NOTHING, db_column='hashkeymeasurement', blank=True, null=True)
    hashkeymetadata = models.ForeignKey(Hubmetadata, models.DO_NOTHING, db_column='hashkeymetadata', blank=True, null=True)
    loaddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'linkunitmeta'


class Satdata(models.Model):
    hashkeysatdata = models.OneToOneField(Hubdata, models.DO_NOTHING, db_column='hashkeysatdata', primary_key=True)
    loaddate = models.DateTimeField()
    loadenddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)
    hashdiff = models.CharField(max_length=40, blank=True, null=True)
    myfile = models.BinaryField(blank=True, null=True)
    code_method = models.CharField(max_length=40, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'satdata'
        unique_together = (('hashkeysatdata', 'loaddate'),)


class Satexperiment(models.Model):
    hashkeysatexperiment = models.OneToOneField(Hubexperiment, models.DO_NOTHING, db_column='hashkeysatexperiment', primary_key=True)
    loaddate = models.DateTimeField()
    loadenddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)
    hashdiff = models.CharField(max_length=40, blank=True, null=True)
    researchname = models.CharField(max_length=40, blank=True, null=True)
    researcher = models.CharField(max_length=40, blank=True, null=True)
    institute = models.CharField(max_length=40, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'satexperiment'
        unique_together = (('hashkeysatexperiment', 'loaddate'),)


class Satfactor(models.Model):
    hashkeysatfactor = models.OneToOneField(Hubfactor, models.DO_NOTHING, db_column='hashkeysatfactor', primary_key=True)
    loaddate = models.DateTimeField()
    loadenddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)
    hashdiff = models.CharField(max_length=40, blank=True, null=True)
    factortype = models.CharField(max_length=20, blank=True, null=True)
    unit = models.CharField(max_length=20, blank=True, null=True)
    value = models.DecimalField(max_digits=40, decimal_places=0, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'satfactor'
        unique_together = (('hashkeysatfactor', 'loaddate'),)


class Satmeasurement(models.Model):
    hashkeysatmeasurement = models.OneToOneField(Hubmeasurement, models.DO_NOTHING, db_column='hashkeysatmeasurement', primary_key=True)
    loaddate = models.DateTimeField()
    loadenddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)
    hashdiff = models.CharField(max_length=40, blank=True, null=True)
    name = models.CharField(max_length=30, blank=True, null=True)
    description = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'satmeasurement'
        unique_together = (('hashkeysatmeasurement', 'loaddate'),)


class Satmetadata(models.Model):
    hashkeysatmetadata = models.OneToOneField(Hubmetadata, models.DO_NOTHING, db_column='hashkeysatmetadata', primary_key=True)
    loaddate = models.DateTimeField()
    loadenddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)
    hashdiff = models.CharField(max_length=40, blank=True, null=True)
    metakey = models.CharField(max_length=50, blank=True, null=True)
    metavalue = models.CharField(max_length=800, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'satmetadata'
        unique_together = (('hashkeysatmetadata', 'loaddate'),)


class Satprocesseddata(models.Model):
    hashkeysatprocesseddata = models.OneToOneField(Hubprocesseddata, models.DO_NOTHING, db_column='hashkeysatprocesseddata', primary_key=True)
    loaddate = models.DateTimeField()
    loadenddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)
    hashdiff = models.CharField(max_length=40, blank=True, null=True)
    myfile = models.BinaryField(blank=True, null=True)
    decode_method = models.CharField(max_length=40, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'satprocesseddata'
        unique_together = (('hashkeysatprocesseddata', 'loaddate'),)


class Satsession(models.Model):
    hashkeysatsession = models.OneToOneField(Hubsession, models.DO_NOTHING, db_column='hashkeysatsession', primary_key=True)
    loaddate = models.DateTimeField()
    loadenddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)
    hashdiff = models.CharField(max_length=40, blank=True, null=True)
    name = models.CharField(max_length=30, blank=True, null=True)
    description = models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'satsession'
        unique_together = (('hashkeysatsession', 'loaddate'),)


class Satsubject(models.Model):
    hashkeysatsubject = models.OneToOneField(Hubsubject, models.DO_NOTHING, db_column='hashkeysatsubject', primary_key=True)
    loaddate = models.DateTimeField()
    loadenddate = models.DateTimeField(blank=True, null=True)
    recordsource = models.CharField(max_length=80, blank=True, null=True)
    hashdiff = models.CharField(max_length=40, blank=True, null=True)
    name = models.CharField(max_length=40, blank=True, null=True)
    age = models.CharField(max_length=10, blank=True, null=True)
    sex = models.CharField(max_length=10, blank=True, null=True)
    comment = models.CharField(max_length=400, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'satsubject'
        unique_together = (('hashkeysatsubject', 'loaddate'),)
