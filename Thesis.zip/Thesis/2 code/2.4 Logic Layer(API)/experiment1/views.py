# Author: Sheng Li

# Find config.ini
import os
import configparser
cf = configparser.ConfigParser()
cf.read(os.path.dirname(os.getcwd()) + '/' + 'config.ini')

# ↓ -----CONFIG----- ↓
database_name = "datavault_smd_sp_g01"
database_user = cf.get('Postgresql','database_user')
database_password = cf.get('Postgresql','database_password')
database_host = cf.get('Postgresql','database_host')
database_port = cf.get('Postgresql','database_port')
# ↑ -----CONFIG----- ↑

from django.shortcuts import render
from django.http import JsonResponse
import pickle
import psycopg2

# Create your views here.

def experiment1(request):
    subject = request.POST.get('subject')
    session = request.POST.get('session')
    measurement=request.POST.get('measurement')
    channel = request.POST.get('channel')
    if subject == None  or session==None or measurement==None  or channel==None:
        return render(request,'experiment1.html')
    connection = psycopg2.connect(database=database_name, user=database_user, password=database_password, host=database_host, port=int(database_host))
    cur = connection.cursor()
    dataid = "'" + subject + "_" + session + "_" + measurement + "'"
    ch = "CH" + channel
    a = "SELECT satdata.myfile FROM satdata,hubdata WHERE hubdata.dataid=%s AND hubdata.hashkeydata=satdata.hashkeysatdata" % dataid
    cur.execute(a)
    temp = cur.fetchall()
    encoded = temp[0][0]
    encoded = encoded.tobytes()
    data = pickle.loads(encoded)
    time = data['Time']
    Ch = data[ch]
    Time = []
    Channel = []
    for i in range(len(time)):
        temp = time[i]
        temp = temp.split(":")
        Sum = float(temp[0]) * 3600 + float(temp[1]) * 60 + float(temp[2])
        Time.append(Sum)
        Channel.append(float(Ch[i]))
    result = {"Time": Time, "Channel": Channel}
    subjectid = "'" + subject + "'"
    cur.execute(
        "SELECT satmetadata.metakey,satmetadata.metavalue FROM satmetadata,hubmetadata,linkunitmeta,hubsubject,linkexperimentunit,hubexperimentunit "
        "WHERE hubsubject.subjectid= %s AND hubsubject.hashkeysubject=linkexperimentunit.hashkeysubject "
        "AND linkexperimentunit.hashkeyexperimentunit=hubexperimentunit.hashkeyexperimentunit "
        "AND linkunitmeta.hashkeyexperimentunit=hubexperimentunit.hashkeyexperimentunit AND linkunitmeta.hashkeymetadata=hubmetadata.hashkeymetadata "
        "AND hubmetadata.hashkeymetadata=satmetadata.hashkeysatmetadata" % subjectid)
    temp = cur.fetchall()
    l = int(len(temp) / 4)
    metadata=[]
    if session == "Moto":
        for i in range(l):
            dict={}
            dict['Field']=temp[i][0]
            dict['Value']=temp[i][1]
            metadata.append(dict)
    elif session == "Rest":
        for i in range(l, 2 * l):
            dict = {}
            dict['Field'] = temp[i][0]
            dict['Value'] = temp[i][1]
            metadata.append(dict)
    elif session == "ViMo":
        for i in range(2 * l, 3 * l):
            dict = {}
            dict['Field'] = temp[i][0]
            dict['Value'] = temp[i][1]
            metadata.append(dict)
    elif session == "Viso":
        for i in range(3 * l, 4 * l):
            dict={}
            dict['Field']=temp[i][0]
            dict['Value']=temp[i][1]
            metadata.append(dict)
    result['Metadata']=metadata
    cur.close()
    return JsonResponse(result)


