# Author: Sheng Li

from django.urls import path

from . import views

urlpatterns = [
    path('', views.experiment1, name='experiment1'),
    path('experiment1.html',views.experiment1),
]
