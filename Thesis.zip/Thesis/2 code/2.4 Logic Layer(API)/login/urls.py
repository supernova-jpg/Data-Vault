# Author: Sheng Li

from django.urls import path

from . import views

urlpatterns = [
    path('', views.login, name='login'),
    path('search/',views.search,name='search'),
    path('sign/',views.sign,name='sign'),
    path('index.html',views.search,name='index'),
    path('register.html',views.sign,name='register'),
    path('login.html',views.login),
]
