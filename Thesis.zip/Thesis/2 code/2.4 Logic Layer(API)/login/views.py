# Author: Sheng Li

# Find config.ini
import os
import configparser
cf = configparser.ConfigParser()
cf.read(os.path.dirname(os.getcwd()) + '/' + 'config.ini')

# ↓ -----CONFIG----- ↓
database_name = "userdata"
database_user = cf.get('Postgresql','database_user')
database_password = cf.get('Postgresql','database_password')
database_host = cf.get('Postgresql','database_host')
database_port = cf.get('Postgresql','database_port')
# ↑ -----CONFIG----- ↑

from django.shortcuts import render
from django.http import JsonResponse

import  psycopg2

# Create your views here.
def login(request):
    connection=psycopg2.connect(database=database_name, user=database_user, password=database_password, host=database_host, port=int(database_port))
    cur=connection.cursor()
    cur.execute("SELECT * FROM authuser")
    temp=cur.fetchall()
    cur.close()
    username = request.POST.get('username')
    password = request.POST.get('password')
    if username == '' or password == '':
        status = -1
        description = "Username or password cannot be empty!"
        result = {"status": status, "Description": description}
        return JsonResponse(result)
    for i in range(len(temp)):
        if username == temp[i][0] and password == temp[i][1]:
            status=1
            description="Login is successfully!"
            next="http://127.0.0.1:8000/search/"
            result={"status":status,"Description":description,"next":next}
            return JsonResponse(result)
        if username == temp[i][0] and password != temp[i][1]:
            status=0
            description = "Your password is wrong!"
            result = {"status": status, "Description": description}
            return JsonResponse(result)
    return render(request, 'login.html')

def search(request):
    choice=request.POST.get("choice")
    if choice=="Experiment 1":
        status=1
        description="Experiment 1"
        previous="http://127.0.0.1:8000/"
        next="http://127.0.0.1:8000/experiment1/"
        result = {"status": status, "Description": description, "next": next, "previous":previous}
        return JsonResponse(result)
    elif choice=="Experiment 2":
        status = 2
        description = "Experiment 2"
        previous = "http://127.0.0.1:8000/"
        next = "http://127.0.0.1:8000/experiment2/"
        result = {"status": status, "Description": description, "next": next, "previous": previous}
        return JsonResponse(result)
    return render(request, 'index.html')

def sign(request):
    username = request.POST.get('username')
    password1 = request.POST.get('password')
    password2 = request.POST.get('reenterpassword')
    connection=psycopg2.connect(database=database_name, user=database_user, password=database_password, host=database_host, port=int(database_host))
    cur = connection.cursor()
    cur.execute("SELECT * FROM authuser")
    temp = cur.fetchall()
    for i in range(len(temp)):
        if username == temp[i][0]:
            status = -1
            description = "This username exists. Please retype your username!"
            previous = "http://127.0.0.1:8000/"
            result = {"status": status, "Description": description, "previous": previous}
            cur.close()
            return JsonResponse(result)
    if password1!=password2:
        status = 0
        description = "The passwords are different. Please retype your password!"
        previous = "http://127.0.0.1:8000/"
        result = {"status": status, "Description": description, "previous": previous}
        cur.close()
        return JsonResponse(result)
    if username==None or password1==None or password2==None:
        cur.close()
        return render(request, 'sign.html')
    if username!='' and password1!='':
        user = "'" + username + "'"
        password = "'" + password1 + "'"
        insert = "INSERT INTO authuser (username,password,usertype) VALUES(%s, %s,'guest');" % (user, password)
        cur.execute(insert)
        connection.commit()
        cur.close()
        status = 1
        description = "Successfully registered!"
        previous = "http://127.0.0.1:8000/"
        result = {"status": status, "Description": description, "previous": previous}
        return JsonResponse(result)
    else:
        status = -2
        description = "Username or password cannot be empty!"
        result = {"status": status, "Description": description}
        cur.close()
        return JsonResponse(result)
    return render(request, 'sign.html')

