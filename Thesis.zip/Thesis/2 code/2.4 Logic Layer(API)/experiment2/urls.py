# Author: Sheng Li

from django.urls import path

from . import views

urlpatterns = [
    path('', views.experiment2, name='experiment2'),
    path('EEG/', views.EEG, name='EEG'),
    path('FNIRS/', views.FNIRS, name='FNIRS'),
]