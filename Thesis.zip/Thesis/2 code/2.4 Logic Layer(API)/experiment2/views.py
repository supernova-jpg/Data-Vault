# Author: Sheng Li

# Find config.ini
import os
import configparser
cf = configparser.ConfigParser()
cf.read(os.path.dirname(os.getcwd()) + '/' + 'config.ini')

# ↓ -----CONFIG----- ↓
database_name = "datavault_smd_sp_g01"
database_user = cf.get('Postgresql','database_user')
database_password = cf.get('Postgresql','database_password')
database_host = cf.get('Postgresql','database_host')
database_port = cf.get('Postgresql','database_port')
# ↑ -----CONFIG----- ↑

from django.shortcuts import render
from django.http import JsonResponse
import numpy as np
import binascii
import psycopg2

def experiment2(request):
    factor = request.POST.get('factor')
    if factor == "EEG":
        status = 1
        description = "EEG"
        previous = "http://127.0.0.1:8000/experiment2/"
        next = "http://127.0.0.1:8000/experiment2/EEG/"
        result = {"status": status, "Description": description, "next": next, "previous": previous}
        return JsonResponse(result)
    elif factor == "FNIRS":
        status = 2
        description = "FNIRS"
        previous = "http://127.0.0.1:8000/experiment2/"
        next = "http://127.0.0.1:8000/experiment2/FNIRS/"
        result = {"status": status, "Description": description, "next": next, "previous": previous}
        return JsonResponse(result)
    return render(request, 'experiment2.html')

def EEG(request):
    subjectid=request.POST.get('subject')
    sessionid=request.POST.get('session')
    channel=request.POST.get('channel')
    if subjectid==None or sessionid==None or channel==None:
        return render(request, 'EEG.html')
    EEGMachine = ['Fp1', 'AF7', 'AF3', 'AF4', 'AF8', 'F7', 'F5', 'F3', 'F4', 'F6', 'F8', 'FC5', 'FC3', 'FC4', 'FC6', 'C5', 'C6', 'T7', 'T8', 'TP7', 'CP5', 'CP6', 'TP8', 'P7', 'P5', 'P6', 'P8', 'PO7', 'PO8']
    for i in range(len(EEGMachine)):
        if channel==EEGMachine[i]:
            channel = i + 1
    time='mat_'+subjectid+'_'+sessionid+'_c1'
    time="'"+time+"'"
    channel=str(channel+1)
    data='mat_'+subjectid+'_'+sessionid+'_c'+channel
    data="'"+data+"'"
    Timequery="SELECT satdata.myfile FROM hubdata,satdata WHERE hubdata.dataid=%s AND satdata.hashkeysatdata=hubdata.hashkeydata;" %time
    Dataquery="SELECT satdata.myfile FROM hubdata,satdata WHERE hubdata.dataid=%s AND satdata.hashkeysatdata=hubdata.hashkeydata;" %data
    connection = psycopg2.connect(database=database_name, user=database_user, password=database_password, host=database_host, port=int(database_host))
    cur = connection.cursor()
    cur.execute(Timequery)
    temp=cur.fetchall()
    encoded = binascii.a2b_hex(temp[0][0])
    t = np.frombuffer(encoded)
    cur.execute(Dataquery)
    temp=cur.fetchall()
    encoded = binascii.a2b_hex(temp[0][0])
    d = np.frombuffer(encoded)
    Time=t.tolist()
    Channel=d.tolist()
    result={"Time":Time,"Channel":Channel}
    cur.close()
    return JsonResponse(result)

def FNIRS(request):
    subjectid = request.POST.get('subject')
    sessionid = request.POST.get('session')
    wavelength=request.POST.get('Wavelength')
    channel = request.POST.get('channel')
    if subjectid==None or sessionid==None or wavelength==None or channel==None:
        return render(request,'FNIRS.html')
    connection = psycopg2.connect(database=database_name, user=database_user, password=database_password, host=database_host, port=int(database_host))
    if int(subjectid) < 10:
        subjectid = "'control00" + subjectid + "'"
    else:
        subjectid = "'control0" + subjectid + "'"
    sessionid = "'session_" + sessionid + "'"
    wavelength="'fNIRS_Wavelength_" + wavelength + "'"
    cur = connection.cursor()
    cur.execute(
        "SELECT satprocesseddata.myfile FROM linkdatapro,hubprocesseddata,satprocesseddata,hubdata,hubfactor,hubmeasurement,linkdata,hubsession,hubsubject,linkexperimentunit,hubexperimentunit "
        "WHERE hubsubject.subjectid= %s AND hubsession.sessionid= %s "
        "AND hubsubject.hashkeysubject=linkexperimentunit.hashkeysubject "
        "AND hubsession.hashkeysession=linkexperimentunit.hashkeysession "
        "AND linkexperimentunit.hashkeyexperimentunit=hubexperimentunit.hashkeyexperimentunit "
        "AND linkexperimentunit.hashkeyexperimentunit=hubexperimentunit.hashkeyexperimentunit "
        "AND hubexperimentunit.hashkeyexperimentunit=linkdata.hashkeyexperimentunit "
        "AND hubmeasurement.measurementid= 'measurement_2' AND hubmeasurement.hashkeymeasurement=linkdata.hashkeymeasurement "
        "AND hubfactor.factorid=%s AND hubfactor.hashkeyfactor=linkdata.hashkeyfactor "
        "AND linkdata.hashkeydata=hubdata.hashkeydata AND hubdata.hashkeydata=linkdatapro.hashkeydata "
        "AND linkdatapro.hashkeyprocesseddata=hubprocesseddata.hashkeyprocesseddata "
        "AND hubprocesseddata.hashkeyprocesseddata = satprocesseddata.hashkeysatprocesseddata"
        % (subjectid, sessionid, wavelength))
    temp = cur.fetchall()
    encoded = binascii.a2b_hex(temp[0][0])
    data = str(encoded)
    data = data[2:len(data) - 1]
    data = data.replace('\\r\\n', ' ')
    data = data.split()
    dat = np.array(data)
    h = int(len(dat) / 48)
    dat = dat.reshape(h, 48)
    Oxy=[]
    Deoxy=[]
    Time=[]
    j=int(channel)
    for i in range(2, len(dat)):
        Oxy.append(float(dat[i][2 * j - 2]))
        Deoxy.append(float(dat[i][2 * j - 1]))
        Time.append(0.001*(i-2))
    result= {"Time": Time, "Oxy": Oxy, "Deoxy": Deoxy}
    cur.execute("SELECT satmetadata.metakey,satmetadata.metavalue FROM satmetadata,hubmetadata,linkunitmeta,hubsession,hubsubject,linkexperimentunit,hubexperimentunit "
        "WHERE hubsubject.subjectid= %s AND hubsession.sessionid= %s AND hubsubject.hashkeysubject=linkexperimentunit.hashkeysubject "
        "AND hubsession.hashkeysession=linkexperimentunit.hashkeysession AND linkexperimentunit.hashkeyexperimentunit=hubexperimentunit.hashkeyexperimentunit "
        "AND linkunitmeta.hashkeyexperimentunit=hubexperimentunit.hashkeyexperimentunit AND linkunitmeta.hashkeymetadata=hubmetadata.hashkeymetadata "
        "AND hubmetadata.hashkeymetadata=satmetadata.hashkeysatmetadata" % (subjectid, sessionid))
    temp = cur.fetchall()
    metadata=[]
    for i in range(len(temp)-7):
        dict = {}
        dict['Field'] = temp[i][0]
        dict['Value'] = temp[i][1]
        metadata.append(dict)
    metadata.append({'Field':temp[len(temp)-5][0],'Value':temp[len(temp)-5][1]})
    result['Metadata'] = metadata
    cur.close()
    return JsonResponse(result)
