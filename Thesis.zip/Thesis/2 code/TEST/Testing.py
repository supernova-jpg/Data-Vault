# Author: Wenhao Li

import psycopg2
import pandas as pd
import os
import pickle
import datacompy

#The code below is used to perform data testing
#Use the function datatesting() to carry out a binary data rollback and compare it with the source data
#This document focuses on the data comparison for Experiment_1
data_path='D:/123.pw/venv/assignment2/testing'
database="DataVault"
user="postgres"
password="123456"
host="81.69.223.209"
port="63719"

file_list=[]
for root, dirs, files in os.walk(data_path):
    file_list=files
def path(i):
    filepath=os.path.join(data_path,file_list[i])
    return filepath
def f(c):
    '''
    Args:Handling of data with file name exceptions when reading files
        c:file name

    Returns:correct file name

    '''
    f=c.split('_')
    if len(f[0])<6:
        str=c.replace('VM010','VM0010')
        return str
    else:
        return c
def id_check(id):
    try:
        print('The name of the file you will be querying is %s' %file_list[int(id)])
        return int(id)
    except:
        print('The name(number) of the file you will be querying is %s' %id)
        for i in range(len(file_list)):
            if id==file_list[i]:
                print('The number of the file you will be querying is %d' %i)
                return(i)
        else:
            print('The file name(number) of the query is in the wrong format or does not exist')

def data_test(no):
    '''
    Args:Pre-processing of data and then conversion to binary files
        no: Receiving Document Number

    Returns:Corresponding binary file

    '''
    f = open(path(no))
    data = f.readlines()[40:]
    for i in range(len(data)):
        data[i] = data[i].replace('\n', '')
    for i in range(len(data)):
        data[i] = data[i].replace('E', '')
    for i in range(len(data)):
        data[i] = data[i].split(',')
        if len(data[i]) < 30:
            add = ['0', '0', '0']
            data[i] += add
    title = data[0]
    sp_data = pd.DataFrame(data[1:])
    sp_data.columns = title
    return sp_data


def getdata(i):
    connection = psycopg2.connect(database=database, user=user, password=password, host=host, port=port)
    cur = connection.cursor()
    dataid = "'" + f(file_list[i]).replace('.csv','') + "'"
    a = "SELECT satdata.myfile FROM satdata,hubdata WHERE hubdata.dataid=%s AND hubdata.hashkeydata=satdata.hashkeysatdata" % dataid
    cur.execute(a)
    temp = cur.fetchall()
    encoded = temp[0][0]
    encoded = encoded.tobytes()
    data = pickle.loads(encoded)
    return data

def datatesting():
    id=input('Please enter the serial number or filename of the file you want to detect (1 or "*.csv"):')
    num=id_check(id)
    get=getdata(num)
    key=list(get.keys())
    com=data_test(num)
    compare=datacompy.Compare(get,com,join_columns=key)
    print(compare.matches())
    print(compare.report())

datatesting()